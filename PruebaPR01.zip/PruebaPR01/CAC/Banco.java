package CAC;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathConstants;
import java.io.File;

public class Banco {
    private Map<String, Cliente> clientes = new HashMap<>();
    private Map<String, Cuenta> cuentas = new HashMap<>();    

    //clase cliente---------------------------------------------------------------------------------------------
        public void crearCliente() {
        Scanner scanner = new Scanner(System.in);
        
        String nombre;
        do {
            System.out.print("Ingrese el nombre completo del cliente: ");
            nombre = scanner.nextLine();
        } while (nombre.isEmpty());
    
        String identificacion;
        do {
            System.out.print("Ingrese la identificación del cliente: ");
            identificacion = scanner.nextLine();
        } while (identificacion.isEmpty());
    
        String telefono;
        do {
            System.out.print("Ingrese el número telefónico del cliente (8 dígitos): ");
            telefono = scanner.nextLine();
            if (!validarTelefono(telefono)) {
                System.out.println("Número de teléfono inválido. Debe tener 8 dígitos.");
            }
        } while (!validarTelefono(telefono));
    
        String correo;
        do {
            System.out.print("Ingrese la dirección de correo electrónico del cliente: ");
            correo = scanner.nextLine();
            if (!validarCorreo(correo)) {
                System.out.println("Correo electrónico inválido.");
            }
        } while (!validarCorreo(correo));
    
        Cliente nuevoCliente = new Cliente(nombre, identificacion, telefono, correo);
    
        System.out.println("\nSe ha creado un nuevo cliente en el sistema, los datos del cliente son:");
        System.out.println("Nombre completo: " + nuevoCliente.getNombre());
        System.out.println("Identificación: " + nuevoCliente.getIdentificacion());
        System.out.println("Número de teléfono: " + nuevoCliente.getTelefono());
        System.out.println("Dirección de correo electrónico: " + nuevoCliente.getCorreo());
    }
    
    public Cliente buscarClientePorIdentificacion(String identificacion) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse("clientes.xml");
    
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();
            XPathExpression expr = xpath.compile("/Clientes/Cliente[Identificacion='" + identificacion + "']");
    
            NodeList nodeList = (NodeList) expr.evaluate(document, javax.xml.xpath.XPathConstants.NODESET);
            
            if (nodeList.getLength() > 0) {
                Element clienteElement = (Element) nodeList.item(0);
                String nombre = clienteElement.getElementsByTagName("Nombre").item(0).getTextContent();
                String telefono = clienteElement.getElementsByTagName("Telefono").item(0).getTextContent();
                String correo = clienteElement.getElementsByTagName("Correo").item(0).getTextContent();
    
                return new Cliente(nombre, identificacion, telefono, correo);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private boolean validarTelefono(String telefono) {
        return telefono.matches("\\d{8}");  
    }
    
    private boolean validarCorreo(String correo) {
        return correo.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$");
    }
//clase cliente--------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
//clase cuenta---------------------------------------------------------------------------------------------------------
    public boolean validarPIN(String pin) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d]{6}$";
        return pin.matches(regex);
    }
    
    public void crearCuenta(Cliente cliente, String pin, double depositoInicial) {
        if (!validarPIN(pin)) {
            throw new IllegalArgumentException("PIN no cumple con los requisitos de formato.");
        }
    
        Cuenta nuevaCuenta = new Cuenta(cliente, pin, depositoInicial);
        cuentas.put(nuevaCuenta.getNumeroCuenta(), nuevaCuenta);
    
        System.out.println("\nSe ha creado una nueva cuenta en el sistema, los datos de la cuenta son:");
        System.out.println("Número de cuenta: " + nuevaCuenta.getNumeroCuenta());
        System.out.println("Estatus de la cuenta: " + nuevaCuenta.getEstatus());
        System.out.printf("Saldo actual: %.2f%n", nuevaCuenta.getSaldo());
        System.out.println("Nombre del dueño de la cuenta: " + cliente.getNombre());
    }
//clase cuenta --------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
//clase ---------------------------------------------------------------------------------------------------------
}
