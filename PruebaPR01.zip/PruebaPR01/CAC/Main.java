package CAC;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Banco banco = new Banco();

        while (true) {
            System.out.println("\nBienvenido al Banco Limón");
            System.out.println("1. Crear cliente");
            System.out.println("2. Crear cuenta");
            System.out.println("3. Cambiar pin de cuenta");
            System.out.println("4. Realizar Depósito en colones");
            System.out.println("5. Realizar Depósito con cambio de moneda");
            System.out.println("21. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1: // crear cliente
                    System.out.print("Ingrese el nombre completo del cliente: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese la identificación del cliente: ");
                    String identificacion = scanner.nextLine();
                    System.out.print("Ingrese el número telefónico del cliente: ");
                    String telefono = scanner.nextLine();
                    System.out.print("Ingrese la dirección de correo electrónico del cliente: ");
                    String correo = scanner.nextLine();

                    Cliente nuevoCliente = new Cliente(nombre, identificacion, telefono, correo);

                    nuevoCliente.guardarEnXML();

                    System.out.println("\nSe ha creado un nuevo cliente en el sistema, los datos del cliente son:");
                    System.out.println("Nombre completo: " + nuevoCliente.getNombre());
                    System.out.println("Identificación: " + nuevoCliente.getIdentificacion());
                    System.out.println("Número de teléfono: " + nuevoCliente.getTelefono());
                    System.out.println("Dirección de correo electrónico: " + nuevoCliente.getCorreo());
                    break;
                
                case 2: // crear cuenta
                    System.out.print("Ingrese la identificación del cliente: ");
                    String idCliente = scanner.nextLine();
                
                    Cliente cliente = banco.buscarClientePorIdentificacion(idCliente);
                    if (cliente == null) {
                        System.out.println("No se encontró un cliente con esa identificación. No es posible crear la cuenta.");
                        break;
                    }
                
                    System.out.println("*****************************************************************************");
                    System.out.println("* Datos del cliente encontrado:");
                    System.out.println("* Nombre completo: " + cliente.getNombre());
                    System.out.println("* Identificación: " + cliente.getIdentificacion());
                    System.out.println("* Número de teléfono: " + cliente.getTelefono());
                    System.out.println("* Correo electrónico: " + cliente.getCorreo());
                    System.out.println("*****************************************************************************");
                
                    String pin;
                    do {
                        System.out.print("Ingrese un PIN para la cuenta (6 caracteres alfanuméricos con al menos una mayúscula y un número): ");
                        pin = scanner.nextLine();
                
                        if (!banco.validarPIN(pin)) {
                            System.out.println("El PIN no cumple con los requisitos de formato. Asegúrate de ingresar 6 caracteres alfanuméricos con al menos una mayúscula y un número.");
                        }
                    } while (!banco.validarPIN(pin)); 
                
                    double depositoInicial;
                    do {
                        System.out.print("Ingrese el monto de depósito inicial: ");
                        while (!scanner.hasNextDouble()) {
                            System.out.println("Por favor ingrese un número válido.");
                            scanner.next();
                        }
                        depositoInicial = scanner.nextDouble();
                    } while (depositoInicial < 0);
                
                    banco.crearCuenta(cliente, pin, depositoInicial);
                    System.out.println("Cuenta creada exitosamente.");
                    break;

                case 3: // Cambiar PIN
                    System.out.print("Ingrese el número de cuenta: ");
                    String numeroCuenta = scanner.nextLine();
                    
                    System.out.print("Ingrese el PIN actual: ");
                    String pinActual = scanner.nextLine();
                    
                    System.out.print("Ingrese el nuevo PIN (6 caracteres alfanuméricos con al menos una mayúscula y un número): ");
                    String nuevoPIN = scanner.nextLine();
                    
                    Cuenta.editarPinDeCuenta(numeroCuenta, pinActual, nuevoPIN);
                    break;
                
                case 4: // Realizar Depósito
                    System.out.print("Ingrese el número de cuenta para el depósito: ");
                    String numeroCuentaDeposito = scanner.nextLine(); // Cambié el nombre de la variable
                
                    // Buscar la cuenta en el sistema
                    Cuenta cuentaDeposito = Cuenta.buscarCuentaPorNumero(numeroCuentaDeposito);
                
                    if (cuentaDeposito != null) {
                        String montoDepositoStr;
                        int montoDeposito = -1;  // Valor inicial no válido para iniciar el bucle
                
                        // Bucle para asegurar que el monto sea un número entero válido
                        while (montoDeposito < 0) {
                            System.out.print("Ingrese el monto del depósito (sin decimales): ");
                            montoDepositoStr = scanner.nextLine();
                
                            // Validar que el monto sea un número entero válido
                            if (montoDepositoStr.matches("\\d+")) {
                                montoDeposito = Integer.parseInt(montoDepositoStr);
                            } else {
                                System.out.println("Monto inválido. El monto debe ser un número entero sin decimales.");
                            }
                        }
                
                        // Llamar a la función de depósito en la clase Transaccion
                        Transaccion.realizarDeposito(cuentaDeposito, montoDeposito);
                
                    } else {
                        System.out.println("No se encontró ninguna cuenta con ese número.");
                    }
                    break;
                
               case 5: // Realizar Depósito con cambio de moneda (dólares a colones)
                    System.out.print("Ingrese el número de cuenta: ");
                    String numeroCuentaDepositoDolares = scanner.nextLine();
                
                    // Buscar la cuenta en el sistema
                    Cuenta cuentaDepositoDolares = Cuenta.buscarCuentaPorNumero(numeroCuentaDepositoDolares);
                
                    if (cuentaDepositoDolares != null) {
                        String montoDepositoDolaresStr;
                        int montoDepositoDolares = -1;  // Valor inicial no válido para iniciar el bucle
                
                        // Bucle para asegurar que el monto sea un número entero válido
                        while (montoDepositoDolares < 0) {
                            System.out.print("Ingrese el monto del depósito en dólares (sin decimales): ");
                            montoDepositoDolaresStr = scanner.nextLine();
                
                            if (montoDepositoDolaresStr.matches("\\d+")) {
                                montoDepositoDolares = Integer.parseInt(montoDepositoDolaresStr);
                            } else {
                                System.out.println("Monto inválido. El monto debe ser un número entero sin decimales.");
                            }
                        }
                
                        // Llamar a la función de depósito con cambio de moneda en la clase Transaccion
                        Transaccion.realizarDepositoConCambioMoneda(cuentaDepositoDolares, montoDepositoDolares);
                    } else {
                        System.out.println("No se encontró ninguna cuenta con ese número.");
                    }
                    break;

                case 21: // salir
                    System.out.println("Gracias por usar Banco Limón. ¡Hasta luego!");
                    System.exit(0);

                default:
                    System.out.println("Opción no válida, intente de nuevo.");
            }
        }
    }
}
