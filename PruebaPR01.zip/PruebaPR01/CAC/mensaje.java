package CAC;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class mensaje {
    public static final String ACCOUNT_SID = "AC0c231832b5f3654cfd1a38d5ee63ce55";
    public static final String AUTH_TOKEN = "afe3a64ec6e39d7e14627c53e42cf363";

    public static void main(String[] args) {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        Message message = Message.creator(
                new PhoneNumber("+50684260683"),
                new PhoneNumber("+12025178598"),
                "Este es un mensaje de prueba desde Java").create();

        System.out.println("Mensaje enviado con SID: " + message.getSid());
    }
}
