package CAC;

import javax.xml.soap.*;
import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TipoCambioBCCR {

    private static final String SERVICE_URL = "https://gee.bccr.fi.cr/Indicadores/Suscripciones/WS/wsindicadoreseconomicos.asmx";

    public static void main(String[] args) {
        try {
            // solicitud para compra
            String tipoCambioCompra = obtenerTipoCambio("317");
            // Solicitud para venta
            String tipoCambioVenta = obtenerTipoCambio("318");

            System.out.println("Tipo de cambio de compra hoy: " + tipoCambioCompra);
            System.out.println("Tipo de cambio de venta hoy: " + tipoCambioVenta);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String obtenerTipoCambio(String codigoIndicador) throws Exception {
        LocalDate fechaActual = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String fechaHoy = fechaActual.format(formatter);

        // Crea conexión SOAP
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();

        SOAPMessage soapMessage = crearSolicitudSOAP(codigoIndicador, fechaHoy, fechaHoy);

        SOAPMessage soapResponse = soapConnection.call(soapMessage, SERVICE_URL);

        // Procesa la respuesta a texto
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        soapResponse.writeTo(out);
        String responseString = new String(out.toByteArray());

        String decodedResponse = responseString.replace("&lt;", "<").replace("&gt;", ">");

        return extraerValorTipoCambio(decodedResponse);
    }

    private static SOAPMessage crearSolicitudSOAP(String codigoIndicador, String fechaInicio, String fechaFin) throws Exception {
        // Crear mensaje SOAP
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();

        SOAPPart soapPart = soapMessage.getSOAPPart();

        String serverURI = "http://ws.sdde.bccr.fi.cr";

        // Construir el SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("ws", serverURI);

        //cuerpo del mensaje SOAP
        SOAPBody soapBody = envelope.getBody();
        SOAPElement soapBodyElem = soapBody.addChildElement("ObtenerIndicadoresEconomicosXML", "ws");
        SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("Indicador", "ws");
        soapBodyElem1.addTextNode(codigoIndicador); 
        SOAPElement soapBodyElem2 = soapBodyElem.addChildElement("FechaInicio", "ws");
        soapBodyElem2.addTextNode(fechaInicio);
        SOAPElement soapBodyElem3 = soapBodyElem.addChildElement("FechaFinal", "ws");
        soapBodyElem3.addTextNode(fechaFin); 
        SOAPElement soapBodyElem4 = soapBodyElem.addChildElement("Nombre", "ws");
        soapBodyElem4.addTextNode("Importador Tico"); // Nombre del usuario
        SOAPElement soapBodyElem5 = soapBodyElem.addChildElement("SubNiveles", "ws");
        soapBodyElem5.addTextNode("N"); // Subniveles (S/N)
        SOAPElement soapBodyElem6 = soapBodyElem.addChildElement("CorreoElectronico", "ws");
        soapBodyElem6.addTextNode("calvoporrasyeremi@gmail.com"); // Correo electrónico
        SOAPElement soapBodyElem7 = soapBodyElem.addChildElement("Token", "ws");
        soapBodyElem7.addTextNode("IIAMMCYIC9"); // Token de suscripción

        soapMessage.saveChanges();

        return soapMessage;
    }

    private static String extraerValorTipoCambio(String responseString) {
        String marker = "<NUM_VALOR>";
        String endMarker = "</NUM_VALOR>";
        int startIndex = responseString.indexOf(marker);
        if (startIndex != -1) {
            int endIndex = responseString.indexOf(endMarker, startIndex);
            if (endIndex != -1) {
                // Extraer el valor entre <NUM_VALOR> y </NUM_VALOR>
                return responseString.substring(startIndex + marker.length(), endIndex).trim();
            }
        }
        return "No se encontró el valor de tipo de cambio";
    }
}

