package CAC;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathExpressionException;
import org.w3c.dom.NodeList;

public class Cuenta {
    private String numeroCuenta;
    private String fechaCreacion;
    private String estatus;
    private double saldo;
    private Cliente cliente;
    private String PIN;
    private int intentosFallidos;
    private ArrayList<Transaccion> transacciones;

    public Cuenta(Cliente cliente, String pin, double depositoInicial) {
        Scanner scanner = new Scanner(System.in);
        while (!validarPIN(pin)) {
            System.out.print("PIN no cumple con los requisitos. Ingrese un PIN válido: ");
            pin = scanner.nextLine();
        }

        while (depositoInicial < 0) {
            System.out.print("El depósito inicial no puede ser negativo. Ingrese un monto válido: ");
            while (!scanner.hasNextDouble()) {
                System.out.print("Por favor ingrese un número válido: ");
                scanner.next();
            }
            depositoInicial = scanner.nextDouble();
        }

        this.numeroCuenta = generarNumeroCuenta();
        this.fechaCreacion = obtenerFechaActual();
        this.estatus = "Activa";
        this.saldo = depositoInicial;
        this.cliente = cliente;
        this.PIN = encriptarPIN(pin);
        this.intentosFallidos = 0;
        this.transacciones = new ArrayList<>();

        guardarCuentaEnXML();
    }

    public boolean validarPIN(String pin) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d]{6}$";
        return pin.matches(regex);
    }

    private String generarNumeroCuenta() {
        Random random = new Random();
        return "CTA" + (random.nextInt(9999) + 1); 
    }

    private String obtenerFechaActual() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(new Date());
    }

    private String encriptarPIN(String pin) {
        return Integer.toHexString(pin.hashCode());
    }

    public String getPIN() {
        return this.PIN;
    }

    public boolean verificarPIN(String pinIngresado) {
        // Encripta el PIN ingresado para compararlo con el PIN almacenado
        String pinEncriptado = encriptarPIN(pinIngresado);
        if (this.PIN.equals(pinEncriptado)) {
            intentosFallidos = 0;
            return true;
        } else {
            intentosFallidos++;
            if (intentosFallidos >= 3) {
                this.estatus = "Inactiva";
                System.out.println("La cuenta ha sido inactivada por demasiados intentos fallidos.");
            }
            return false;
        }
    }

    public void guardarCuentaEnXML() {
        try {
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document document;
            
            File file = new File("cuentas.xml");
            if (file.exists()) {
                document = documentBuilder.parse(file);
            } else {
                document = documentBuilder.newDocument();
                Element root = document.createElement("Cuentas");
                document.appendChild(root);
            }
            
            // Verifica si la cuenta ya existe
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();
            XPathExpression expr = xpath.compile("/Cuentas/Cuenta[NumeroCuenta='" + this.numeroCuenta + "']");
            
            NodeList nodeList = (NodeList) expr.evaluate(document, XPathConstants.NODESET);
            
            if (nodeList.getLength() > 0) {
                // Actualiza la cuenta existente
                Element cuentaElement = (Element) nodeList.item(0);
                cuentaElement.getElementsByTagName("Saldo").item(0).setTextContent(String.valueOf(this.saldo));
                cuentaElement.getElementsByTagName("Estatus").item(0).setTextContent(this.estatus);
                cuentaElement.getElementsByTagName("PIN").item(0).setTextContent(this.PIN);
            } else {
                Element cuentaElement = document.createElement("Cuenta");
                document.getDocumentElement().appendChild(cuentaElement);
                
                agregarElemento(document, cuentaElement, "NumeroCuenta", this.numeroCuenta);
                agregarElemento(document, cuentaElement, "FechaCreacion", this.fechaCreacion);
                agregarElemento(document, cuentaElement, "Estatus", this.estatus);
                agregarElemento(document, cuentaElement, "Saldo", String.valueOf(this.saldo));
                agregarElemento(document, cuentaElement, "NombreCliente", this.cliente.getNombre());
                agregarElemento(document, cuentaElement, "IdentificacionCliente", this.cliente.getIdentificacion());
                agregarElemento(document, cuentaElement, "PIN", this.PIN); 
            }
            
            // Guarda los cambios 
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(new File("cuentas.xml"));
            
            transformer.transform(domSource, streamResult);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void agregarElemento(Document document, Element parent, String tagName, String textContent) {
        Element element = document.createElement(tagName);
        element.appendChild(document.createTextNode(textContent));
        parent.appendChild(element);
    }

    //sobrecarga de constructor para funcion de buscar por numero --------------------------------------------------------------------------------------------------------
    public Cuenta(Cliente cliente, String numeroCuenta, String fechaCreacion, String estatus, double saldo, String pinEncriptado) {
        this.numeroCuenta = numeroCuenta;
        this.fechaCreacion = fechaCreacion;
        this.estatus = estatus;
        this.saldo = saldo;
        this.cliente = cliente;
        this.PIN = pinEncriptado;
        this.intentosFallidos = 0;
    }
    //sobrecarga de constructor para funcion de buscar por numero ---------------------------------------------------------------------------------------------------------
    
    public static Cuenta buscarCuentaPorNumero(String numeroCuenta) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse("cuentas.xml");
    
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xpath = xPathFactory.newXPath();
            XPathExpression expr = xpath.compile("/Cuentas/Cuenta[NumeroCuenta='" + numeroCuenta + "']");
    
            NodeList nodeList = (NodeList) expr.evaluate(document, XPathConstants.NODESET);
    
            if (nodeList.getLength() > 0) {
                Element cuentaElement = (Element) nodeList.item(0);
    
                String numero = cuentaElement.getElementsByTagName("NumeroCuenta").item(0).getTextContent();
                String fechaCreacion = cuentaElement.getElementsByTagName("FechaCreacion").item(0).getTextContent();
                String estatus = cuentaElement.getElementsByTagName("Estatus").item(0).getTextContent();
                double saldo = Double.parseDouble(cuentaElement.getElementsByTagName("Saldo").item(0).getTextContent());
                String pinEncriptado = cuentaElement.getElementsByTagName("PIN").item(0).getTextContent();
    
                String nombreCliente = cuentaElement.getElementsByTagName("NombreCliente").item(0).getTextContent();
                String identificacionCliente = cuentaElement.getElementsByTagName("IdentificacionCliente").item(0).getTextContent();
    
                Cliente cliente = new Cliente(nombreCliente, identificacionCliente);
    
                Cuenta cuenta = new Cuenta(cliente, numero, fechaCreacion, estatus, saldo, pinEncriptado);
    
                return cuenta;
            } else {
                System.out.println("Cuenta no encontrada.");
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean verificarPalabra() {
        String palabraAleatoria = generarPalabraAleatoria();
        System.out.println("Se ha enviado una palabra por mensaje de texto: " + palabraAleatoria);

        Scanner scanner = new Scanner(System.in);
        int intentos = 0;

        while (intentos < 3) {
            System.out.print("Ingrese la palabra que recibió: ");
            String palabraIngresada = scanner.nextLine();

            if (palabraAleatoria.equals(palabraIngresada)) {
                System.out.println("Palabra verificada correctamente. Puede continuar.");
                return true;
            } else {
                intentos++;
                if (intentos < 3) {
                    System.out.println("Palabra incorrecta. Se enviará una nueva palabra.");
                    palabraAleatoria = generarPalabraAleatoria();
                    System.out.println("Nueva palabra: " + palabraAleatoria);
                }
            }
        }

        this.estatus = "Inactiva";
        System.out.println("Se ha inactivado la cuenta por demasiados intentos fallidos.");
        return false;
    }

    private String generarPalabraAleatoria() {
        String letras = "abcdefghijklmnopqrstuvwxyz";
        Random random = new Random();
        StringBuilder palabra = new StringBuilder();
        for (int i = 0; i < 7; i++) {
            int index = random.nextInt(letras.length());
            palabra.append(letras.charAt(index));
        }
        return palabra.toString();
    }

    public void cambiarPIN(String nuevoPIN) {
        if (validarPIN(nuevoPIN)) {
            this.PIN = encriptarPIN(nuevoPIN);
            System.out.println("PIN cambiado exitosamente.");
            guardarCuentaEnXML(); 
        } else {
            System.out.println("Nuevo PIN no cumple con el formato requerido.");
        }
    }

    public static void editarPinDeCuenta(String numeroCuenta, String pinActual, String nuevoPIN) {
        try {
            Cuenta cuenta = Cuenta.buscarCuentaPorNumero(numeroCuenta);
    
            if (cuenta != null) {
                if (cuenta.verificarPIN(pinActual)) {
                    if (cuenta.validarPIN(nuevoPIN)) {
                        cuenta.cambiarPIN(nuevoPIN);
                        System.out.println("PIN actualizado correctamente en el XML.");
                    } else {
                        System.out.println("El nuevo PIN no cumple con los requisitos.");
                    }
                } else {
                    System.out.println("El PIN actual es incorrecto.");
                }
            } else {
                System.out.println("No se encontró ninguna cuenta con ese número.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //---------------------------------------------------------------------------------------------------------------------
    //apoyo para clase transaccion
    public void realizarDeposito(double monto) {
        this.saldo += monto;
    }
    //apoyo para clase transaccion
    //---------------------------------------------------------------------------------------------------------------------
    // Getters
    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public String getEstatus() {
        return estatus;
    }

    public double getSaldo() {
        return saldo;
    }
    
    public Cliente getCliente() {
    return this.cliente;
    }
}
