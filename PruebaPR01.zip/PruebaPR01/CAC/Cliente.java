package CAC;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Cliente {
    private String nombre;
    private String identificacion;
    private String telefono;
    private String correo;

    public Cliente(String nombre, String identificacion, String telefono, String correo) {
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.telefono = validarTelefono(telefono);
        this.correo = validarCorreo(correo);
    }
    
    //sobrecarga de constructor para funcion de buscar por numero --------------------------------------------------------------------------------------------------------
    public Cliente(String nombre, String identificacion) {
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.telefono = "";
        this.correo = "";
    }
    //sobrecarga de constructor para funcion de buscar por numero ---------------------------------------------------------------------------------------------------------

    private String validarTelefono(String telefono) {
        Scanner scanner = new Scanner(System.in);
        String regex = "\\d{8}";  
        while (!Pattern.matches(regex, telefono)) {
            System.out.println("Número de teléfono inválido. Debe contener 8 dígitos. Inténtelo de nuevo:");
            telefono = scanner.nextLine();
        }
        return telefono;
    }

    private String validarCorreo(String correo) {
        Scanner scanner = new Scanner(System.in);
        String regex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        while (!Pattern.matches(regex, correo)) {
            System.out.println("Correo electrónico inválido. Inténtelo de nuevo:");
            correo = scanner.nextLine();
        }
        return correo;
    }

    public void guardarEnXML() {
        try {
            File archivo = new File("clientes.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc;

            if (archivo.exists()) {
                doc = dBuilder.parse(archivo);
                doc.getDocumentElement().normalize();
            } else {
                doc = dBuilder.newDocument();
                Element rootElement = doc.createElement("Clientes");
                doc.appendChild(rootElement);
            }

            Element clienteElement = doc.createElement("Cliente");

            Element nombreElement = doc.createElement("Nombre");
            nombreElement.appendChild(doc.createTextNode(this.nombre));
            clienteElement.appendChild(nombreElement);

            Element idElement = doc.createElement("Identificacion");
            idElement.appendChild(doc.createTextNode(this.identificacion));
            clienteElement.appendChild(idElement);

            Element telefonoElement = doc.createElement("Telefono");
            telefonoElement.appendChild(doc.createTextNode(this.telefono));
            clienteElement.appendChild(telefonoElement);

            Element correoElement = doc.createElement("Correo");
            correoElement.appendChild(doc.createTextNode(this.correo));
            clienteElement.appendChild(correoElement);

            // Agrega el nuevo cliente al documento
            doc.getDocumentElement().appendChild(clienteElement);

            // Guarda los cambios
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(archivo);
            transformer.transform(source, result);

            System.out.println("Cliente guardado en el sistema correctamente.");
        } catch (ParserConfigurationException | TransformerException | IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("Error al procesar el archivo.");
            e.printStackTrace();
        }
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }
}
