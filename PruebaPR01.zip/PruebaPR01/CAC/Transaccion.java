package CAC;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Transaccion {
    private String tipo;
    private double monto;
    private String fecha;
    private boolean conComision;

    public Transaccion(String tipo, double monto, boolean conComision) {
        this.tipo = tipo;
        this.monto = monto;
        this.fecha = obtenerFechaActual();
        this.conComision = conComision;
    }

    public static void realizarDeposito(Cuenta cuenta, int monto) {
        if (monto > 0) {
            double comision = monto * 0.02;
            double montoFinal = monto - comision;
            
            cuenta.realizarDeposito(montoFinal);
            
            System.out.println("Estimado usuario: " + cuenta.getCliente().getNombre() + 
                               ", se han depositado correctamente " + monto + ".00 colones.");
            System.out.println("[El monto real depositado a su cuenta " + cuenta.getNumeroCuenta() + 
                               " es de " + String.format("%.2f", montoFinal) + " colones]");
            System.out.println("[El monto cobrado por concepto de comisión fue de " + 
                               String.format("%.2f", comision) + " colones, que fueron rebajados automáticamente de su saldo actual]");
            
            cuenta.guardarCuentaEnXML();
        } else {
            System.out.println("El monto del depósito debe ser mayor que 0.XX");
        }
    }
    
    public static void realizarDepositoConCambioMoneda(Cuenta cuenta, int montoDolares) {
        try {
            if (montoDolares > 0) {
                String tipoCambioCompraStr = TipoCambioBCCR.obtenerTipoCambio("317");
                double tipoCambioCompra = Double.parseDouble(tipoCambioCompraStr);
    
                double montoColones = montoDolares * tipoCambioCompra;
                double comision = montoColones * 0.02;
                double montoFinal = montoColones - comision;
    
                cuenta.realizarDeposito(montoFinal);
    
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                String fechaActual = sdf.format(new Date());
    
                System.out.println("Estimado usuario: " + cuenta.getCliente().getNombre() +
                                   ", se han recibido correctamente " + montoDolares + ".00 dólares.");
                System.out.println("[Según el BCCR, el tipo de cambio de compra del dólar de hoy " + fechaActual + 
                                   " es: " + tipoCambioCompraStr + "]");
                System.out.println("[El monto equivalente en colones es " + String.format("%.2f", montoColones) + " colones]");
                System.out.println("[El monto real depositado a su cuenta " + cuenta.getNumeroCuenta() +
                                   " es de " + String.format("%.2f", montoFinal) + " colones]");
                System.out.println("[El monto cobrado por concepto de comisión fue de " +
                                   String.format("%.2f", comision) + " colones, que fueron rebajados automáticamente de su saldo actual]");
    
                cuenta.guardarCuentaEnXML();
            } else {
                System.out.println("El monto del depósito debe ser mayor que 0.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    private String obtenerFechaActual() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        return sdf.format(new Date());
    }

    public String getTipo() {
        return tipo;
    }

    public double getMonto() {
        return monto;
    }

    public String getFecha() {
        return fecha;
    }

    public boolean isConComision() {
        return conComision;
    }

    @Override
    public String toString() {
        return "Tipo: " + tipo + ", Monto: " + monto + ", Fecha: " + fecha + ", Comisión: " + (conComision ? "Sí" : "No");
    }
}
